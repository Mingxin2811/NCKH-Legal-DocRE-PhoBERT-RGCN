# Kết quả thực đo (các chỉ số theo %)

| variant   | setting                       |   accuracy_candidates_exact_set |   precision_macro_22 |   f1_macro_22 |   f1_macro_supported |   f1_micro_positive |   candidate_recall |   no_relation_baseline_accuracy |
|:----------|:------------------------------|--------------------------------:|---------------------:|--------------:|---------------------:|--------------------:|-------------------:|--------------------------------:|
| semantic  | gold_entities                 |                           91.36 |                 3.94 |          5.07 |                13.94 |               27.34 |              80.41 |                           97.99 |
| semantic  | predicted_entities_end_to_end |                           91.96 |                 0.67 |          1.08 |                 2.97 |               20.63 |              58.08 |                           98.64 |
| rgcn      | gold_entities                 |                           93.94 |                 7.69 |          9.47 |                26.04 |               37.56 |              80.41 |                           97.99 |
| rgcn      | predicted_entities_end_to_end |                           93.8  |                 1.17 |          1.83 |                 5.03 |               26.97 |              58.08 |                           98.64 |